export type TopupRequest={orderId:string;game:string;playerId:string;serverId?:string;packageCode:string};
export type TopupResult={providerOrderId:string;status:'processing'|'fulfilled'|'failed';message?:string};
export interface TopupProvider{
 createTopup(input:TopupRequest):Promise<TopupResult>;
 getStatus(providerOrderId:string):Promise<TopupResult>;
}
/**
 * Placeholder only. Replace with a contracted, authorized supplier adapter.
 * Never assume all six games are supported by one supplier.
 */
export const topupProvider:TopupProvider={
 async createTopup(){throw new Error('Top-up provider is not configured. Live sales are disabled.');},
 async getStatus(){throw new Error('Top-up provider is not configured.');}
};
