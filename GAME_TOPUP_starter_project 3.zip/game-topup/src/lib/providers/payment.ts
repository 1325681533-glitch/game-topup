export type PaymentRequest={orderId:string;amountSatang:number;description:string};
export type PaymentSession={paymentId:string;checkoutUrl?:string;qrPayload?:string;status:'pending'};
export interface PaymentProvider{createPayment(input:PaymentRequest):Promise<PaymentSession>;verifyWebhook(rawBody:string,signature:string):Promise<boolean>}
/** Placeholder only. Do not accept client screenshots as proof of payment. */
export const paymentProvider:PaymentProvider={
 async createPayment(){throw new Error('Payment provider is not configured. Live payments are disabled.');},
 async verifyWebhook(){return false;}
};
