export const games = [
 {slug:'free-fire',name:'Free Fire',currency:'Diamonds',icon:'💎',enabled:true},
 {slug:'rov',name:'ROV',currency:'คูปอง',icon:'⚔️',enabled:true},
 {slug:'pubg-mobile',name:'PUBG Mobile',currency:'UC',icon:'🎯',enabled:true},
 {slug:'mobile-legends',name:'Mobile Legends',currency:'Diamonds',icon:'🔷',enabled:true},
 {slug:'genshin-impact',name:'Genshin Impact',currency:'Genesis Crystals',icon:'✨',enabled:true},
 {slug:'roblox',name:'Roblox',currency:'Robux',icon:'🟦',enabled:true},
] as const;
export type GameSlug = typeof games[number]['slug'];
// Prices intentionally omitted until supplier costs and retail margins are verified.
