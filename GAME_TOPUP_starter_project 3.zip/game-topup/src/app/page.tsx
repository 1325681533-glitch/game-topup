import Link from 'next/link';
import {games} from '@/lib/catalog';
export default function Home(){return <main className="wrap">
 <header className="top"><Link className="logo" href="/">GAME TOPUP</Link><span className="pill">GAME ON • TOP UP FAST</span></header>
 <section className="hero"><span className="pill">WELCOME TO GAME TOPUP</span><h1>เติมเกมง่าย<br/><span style={{color:'#70c2ff'}}>รวดเร็ว ปลอดภัย</span></h1><p className="muted">เลือกเกมที่คุณชอบ แล้วเตรียมเติมได้ในไม่กี่ขั้นตอน</p><p className="notice">ร้านกำลังเตรียมระบบชำระเงินและผู้ให้บริการเติมเกม ขณะนี้ยังไม่เปิดรับเงินจริง</p></section>
 <section className="section"><h2>เลือกเกมที่ต้องการเติม</h2><p className="muted">มีเกมให้เลือก 6 รายการ • ราคาและแพ็กเกจจะแสดงเมื่อยืนยันต้นทุนจากผู้ให้บริการ</p><div className="grid">{games.map(g=><article className="card" key={g.slug}><div className="icon">{g.icon}</div><h3>{g.name}</h3><p className="muted">{g.currency}</p><Link className="btn secondary" href={`/games/${g.slug}`}>ดูรายละเอียด</Link></article>)}</div></section>
 <footer className="foot">© {new Date().getFullYear()} GAME TOPUP • ติดต่อฝ่ายบริการลูกค้าเมื่อร้านเปิดให้บริการ</footer>
 </main>}
