import './globals.css';
import type { Metadata } from 'next';
export const metadata:Metadata={title:'GAME TOPUP | เติมเกมออนไลน์',description:'ร้านเติมเกมออนไลน์ GAME TOPUP',manifest:'/manifest.json'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="th"><body>{children}</body></html>}
