import {NextResponse} from 'next/server';
import {paymentProvider} from '@/lib/providers/payment';
export async function POST(req:Request){
 const raw=await req.text();const signature=req.headers.get('x-provider-signature')??'';
 const valid=await paymentProvider.verifyWebhook(raw,signature);
 if(!valid)return NextResponse.json({error:'Invalid webhook signature'}, {status:401});
 // TODO: parse provider event, enforce idempotency, mark order paid in a DB transaction,
 // then enqueue a top-up job. Never call top-up directly before confirmed payment.
 return NextResponse.json({received:true});
}
