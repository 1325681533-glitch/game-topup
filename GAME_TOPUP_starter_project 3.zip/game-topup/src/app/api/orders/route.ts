import {NextResponse} from 'next/server';
import {createClient} from '@/lib/supabase/server';
import {games} from '@/lib/catalog';
export async function POST(req:Request){
 try{
  const body=await req.json();const {gameSlug,playerId,serverId,packageCode}=body;
  if(!games.some(g=>g.slug===gameSlug)||typeof playerId!=='string'||playerId.trim().length<3||playerId.length>80||typeof packageCode!=='string'||packageCode.length>80)return NextResponse.json({error:'ข้อมูลคำสั่งซื้อไม่ถูกต้อง'}, {status:400});
  // Live checkout is intentionally disabled until payment + supplier adapters are configured.
  return NextResponse.json({error:'ร้านยังไม่เปิดรับคำสั่งซื้อจริง กรุณารอการเปิดระบบชำระเงินและ API',liveSalesEnabled:false}, {status:503});
 }catch{return NextResponse.json({error:'Invalid request'}, {status:400});}
}
