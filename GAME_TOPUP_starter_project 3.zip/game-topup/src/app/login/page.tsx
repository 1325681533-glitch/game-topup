'use client';
import {useState} from 'react';
import {createClient} from '@/lib/supabase/browser';
export default function Login(){
 const [email,setEmail]=useState('');const [password,setPassword]=useState('');const [message,setMessage]=useState('');
 async function submit(e:React.FormEvent){e.preventDefault();const c=createClient();const {error}=await c.auth.signInWithPassword({email,password});if(error){setMessage(error.message);return;}window.location.href='/admin';}
 return <main className="wrap"><h1>เข้าสู่ระบบแอดมิน</h1><form onSubmit={submit}><label>อีเมล</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)} required/><label>รหัสผ่าน</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} required/><button className="btn">เข้าสู่ระบบ</button></form><p className="muted">{message}</p></main>
}
