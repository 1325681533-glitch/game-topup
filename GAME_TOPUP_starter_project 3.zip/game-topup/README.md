# GAME TOPUP — starter project

โครงสร้างเริ่มต้นสำหรับร้านเติมเกม 6 เกม (Free Fire, ROV, PUBG Mobile, Mobile Legends, Genshin Impact, Roblox)

> สถานะ: starter scaffold สำหรับพัฒนาและทดสอบ ยังไม่ใช่ระบบรับเงินจริงหรือเติมเกมจริง
> ร้านจะยังไม่เปิดรับคำสั่งซื้อจริงจนกว่าจะตั้งค่า Supabase, payment gateway, ผู้ให้บริการ top-up API,
> ตรวจสอบสิทธิ์เชิงพาณิชย์, ทดสอบ webhook และผ่าน checklist ในเอกสารนี้

## เทคโนโลยี
- Next.js App Router + TypeScript
- Supabase (Postgres + Auth)
- API adapter สำหรับผู้ให้บริการเติมเกม (ยังเป็น placeholder)
- Payment adapter (ยังเป็น placeholder)
- PWA manifest สำหรับติดตั้งเว็บบนหน้าจอมือถือ

## เริ่มต้นในเครื่อง
1. ติดตั้ง Node.js LTS และ npm
2. `npm install`
3. คัดลอก `.env.example` เป็น `.env.local`
4. สร้าง Supabase project แล้วรัน `supabase/schema.sql` ใน SQL Editor
5. ใส่ Supabase URL และ anon key ใน `.env.local`
6. `npm run dev` แล้วเปิด `http://localhost:3000`

## บัญชีแอดมิน
- สมัครสมาชิกผ่าน Supabase Auth ก่อน
- ใน Supabase SQL Editor รัน:
  `update public.profiles set role = 'admin' where id = '<AUTH_USER_UUID>';`
- อย่าเปิดเผย service role key ใน browser

## เชื่อมผู้ให้บริการเติมเกม
ไฟล์ `src/lib/providers/topup.ts` เป็น interface และ mock adapter เท่านั้น
ก่อนใช้งานจริง ต้องมีสัญญาหรือการอนุญาตจากผู้ให้บริการ, API docs, sandbox, รายการเกม/แพ็กเกจ,
ราคา, minimum wallet/top-up, webhook signature และนโยบาย refund ที่ชัดเจน
จากนั้นสร้าง adapter ใหม่โดยเก็บ API key เป็น server-only environment variable

## เชื่อมระบบรับเงิน
ไฟล์ `src/lib/providers/payment.ts` เป็น interface placeholder เท่านั้น
อย่าเชื่อสลิปหรือข้อมูลจาก browser เป็นหลักฐานการจ่ายเงิน ให้ยืนยันจาก webhook ที่ตรวจสอบลายเซ็น
หรือ API ตรวจสอบธุรกรรมจากผู้ให้บริการชำระเงินเท่านั้น

## ความปลอดภัยที่ต้องทำก่อนเปิดจริง
- เปิด RLS ทุกตาราง และทดสอบด้วยบัญชีลูกค้า/แอดมินคนละบัญชี
- ตรวจสอบ webhook signature, timestamp และ replay protection
- ใช้ idempotency key ป้องกันเติมซ้ำ
- ออกแบบสถานะ: pending_payment -> paid -> processing -> fulfilled / failed / refunded
- ห้ามเติมเกมก่อนยืนยันการชำระเงินจากผู้ให้บริการ
- ตรวจสอบ UID/Server ID และแสดงหน้าทวนข้อมูลก่อนจ่าย
- จำกัด rate, validate input, log audit, ตั้ง backup และ alert
- ทดสอบกรณี webhook ซ้ำ, API timeout, เติมสำเร็จแต่ callback หาย, refund
- ตรวจสอบข้อกำหนดการขายสินค้าดิจิทัลของ App Store/Google Play ก่อนทำ native app
- ตรวจสอบข้อกำหนดภาษี/ธุรกิจ/คุ้มครองผู้บริโภคในไทย

## งบไม่เกิน 1,000 บาท
เริ่มทดสอบด้วยบริการ free tier ที่อนุญาตการใช้งานตามเงื่อนไขเท่านั้น
อย่าซื้อโดเมน, เติม wallet API หรือเปิด payment gateway ก่อนตรวจสอบค่าใช้จ่ายจริง
และยืนยันว่าผู้ให้บริการรองรับทั้ง 6 เกมในราคาที่ทำกำไรได้

## โครงสร้าง
- `src/app` หน้าร้าน, checkout, admin และ API routes
- `src/lib` catalog, Supabase client, provider interfaces
- `supabase/schema.sql` ตารางและ RLS
- `public` PWA assets
