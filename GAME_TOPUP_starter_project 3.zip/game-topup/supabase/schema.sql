create extension if not exists pgcrypto;
create type public.user_role as enum ('customer','admin');
create type public.order_status as enum ('pending_payment','paid','processing','fulfilled','failed','refunded','cancelled');

create table public.profiles(
 id uuid primary key references auth.users(id) on delete cascade,
 email text,
 role public.user_role not null default 'customer',
 created_at timestamptz not null default now()
);
create table public.games(
 slug text primary key,
 name text not null,
 currency text not null,
 enabled boolean not null default true,
 created_at timestamptz not null default now()
);
create table public.packages(
 id uuid primary key default gen_random_uuid(),
 game_slug text not null references public.games(slug),
 provider_code text,
 name text not null,
 face_value text not null,
 cost_satang integer,
 price_satang integer,
 enabled boolean not null default false,
 created_at timestamptz not null default now(),
 check(cost_satang is null or cost_satang >= 0),
 check(price_satang is null or price_satang >= 0)
);
create table public.orders(
 id uuid primary key default gen_random_uuid(),
 user_id uuid references auth.users(id),
 game_slug text not null references public.games(slug),
 player_id text not null,
 server_id text,
 package_code text not null,
 amount_satang integer not null check(amount_satang > 0),
 status public.order_status not null default 'pending_payment',
 payment_reference text unique,
 provider_order_id text unique,
 idempotency_key text unique not null,
 failure_reason text,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create table public.payment_events(
 id uuid primary key default gen_random_uuid(),
 provider_event_id text not null unique,
 order_id uuid references public.orders(id),
 event_type text not null,
 verified boolean not null default false,
 payload jsonb not null default '{}'::jsonb,
 created_at timestamptz not null default now()
);
create table public.topup_events(
 id uuid primary key default gen_random_uuid(),
 order_id uuid not null references public.orders(id),
 provider_event_id text unique,
 status text not null,
 payload jsonb not null default '{}'::jsonb,
 created_at timestamptz not null default now()
);
create table public.audit_logs(
 id uuid primary key default gen_random_uuid(),
 actor_id uuid references auth.users(id),
 action text not null,
 entity_type text not null,
 entity_id text,
 details jsonb not null default '{}'::jsonb,
 created_at timestamptz not null default now()
);

insert into public.games(slug,name,currency) values
('free-fire','Free Fire','Diamonds'),('rov','ROV','คูปอง'),('pubg-mobile','PUBG Mobile','UC'),
('mobile-legends','Mobile Legends','Diamonds'),('genshin-impact','Genshin Impact','Genesis Crystals'),
('roblox','Roblox','Robux') on conflict do nothing;

alter table public.profiles enable row level security;
alter table public.games enable row level security;
alter table public.packages enable row level security;
alter table public.orders enable row level security;
alter table public.payment_events enable row level security;
alter table public.topup_events enable row level security;
alter table public.audit_logs enable row level security;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin'); $$;

create policy "profiles read own or admin" on public.profiles for select using (id=auth.uid() or public.is_admin());
-- Customers cannot update their role or profile privileges directly.
create policy "admin update profiles" on public.profiles for update using (public.is_admin()) with check (public.is_admin());
create policy "games public read" on public.games for select using (enabled=true or public.is_admin());
create policy "packages public read enabled" on public.packages for select using (enabled=true or public.is_admin());
create policy "orders read own or admin" on public.orders for select using (user_id=auth.uid() or public.is_admin());
create policy "admin manage games" on public.games for all using (public.is_admin()) with check (public.is_admin());
create policy "admin manage packages" on public.packages for all using (public.is_admin()) with check (public.is_admin());
create policy "admin manage orders" on public.orders for all using (public.is_admin()) with check (public.is_admin());
create policy "admin read payment events" on public.payment_events for select using (public.is_admin());
create policy "admin read topup events" on public.topup_events for select using (public.is_admin());
create policy "admin read audit logs" on public.audit_logs for select using (public.is_admin());

-- Do not grant customers direct insert/update access to orders or payment events.
-- Create orders only through a server route after auth, price lookup and fraud checks.
-- Add a trigger to create profiles on auth.users insert in production.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$ begin insert into public.profiles(id,email) values(new.id,new.email) on conflict do nothing; return new; end; $$;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
